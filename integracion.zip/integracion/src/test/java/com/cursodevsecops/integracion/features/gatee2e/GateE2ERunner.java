package com.cursodevsecops.integracion.features.gatee2e;

import com.intuit.karate.junit4.Karate;
import org.junit.runner.RunWith;

@RunWith(Karate.class)
public class GateE2ERunner {
}
